//
//  AUSubZone.m
//  LocationReport
//
//  Created by Mark Deraeve on 18/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "AUSubZone.h"


@implementation AUSubZone

@dynamic sz_id;
@dynamic z_id;
@dynamic sz_title;
@dynamic sz_info;
@dynamic sz_date;
@dynamic sz_created;
@dynamic sz_created_by;
@dynamic pic_id;
@dynamic prop_id;
@dynamic sectionIdentifier;
@dynamic sectionIdentifier2;

@end
