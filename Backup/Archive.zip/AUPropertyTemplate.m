//
//  AUPropertyTemplate.m
//  LocationReport
//
//  Created by Mark Deraeve on 18/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "AUPropertyTemplate.h"


@implementation AUPropertyTemplate

@dynamic templ_id;
@dynamic templ_title;
@dynamic prop_type;
@dynamic prop_title;
@dynamic prop_default_value;

@end
