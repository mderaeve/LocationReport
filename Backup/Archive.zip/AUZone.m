//
//  AUZone.m
//  LocationReport
//
//  Created by Mark Deraeve on 18/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "AUZone.h"


@implementation AUZone

@dynamic z_id;
@dynamic z_title;
@dynamic z_info;
@dynamic z_date;
@dynamic z_created;
@dynamic z_created_by;
@dynamic proj_id;
@dynamic pic_id;
@dynamic prop_id;
@dynamic sectionIdentifier;
@dynamic sectionIdentifier2;

@end
