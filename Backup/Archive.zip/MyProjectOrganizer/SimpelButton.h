//
//  SimpelButton.h
//  LocationReport
//
//  Created by Mark Deraeve on 03/06/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpelButton : UIButton

@end
