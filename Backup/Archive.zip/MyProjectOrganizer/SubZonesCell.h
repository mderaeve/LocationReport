//
//  SubZonesCell.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubZonesCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end
