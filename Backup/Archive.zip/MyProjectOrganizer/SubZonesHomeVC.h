//
//  SubZonesHomeVC.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "HomeVC.h"
/*

@interface SubZonesHomeVC : HomeVC <UICollectionViewDataSource, UICollectionViewDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *colSubZones;
@property (weak, nonatomic) IBOutlet UITextField *lblProject;

@property (weak, nonatomic) IBOutlet UITextField *lblZone;
@end
*/