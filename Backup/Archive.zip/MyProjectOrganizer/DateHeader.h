//
//  DateHeader.h
//  LocationReport
//
//  Created by Mark Deraeve on 31/08/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DateHeader : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UILabel *lblDate;

@end
