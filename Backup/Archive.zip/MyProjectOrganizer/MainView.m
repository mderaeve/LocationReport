//
//  MainView.m
//  LocationReport
//
//  Created by Mark Deraeve on 08/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "MainView.h"

@implementation MainView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
    
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        CAGradientLayer *gradient = [CAGradientLayer layer];
        gradient.frame = self.bounds;
        gradient.colors = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:55/255.0 green:96/255.0 blue:124/255.0 alpha:1] CGColor], (id)[[UIColor colorWithRed:153/255.0 green:188/255.0 blue:244/255.0 alpha:1] CGColor], nil];
        [self.layer insertSublayer:gradient atIndex:0];
        // Initialization code
        //[self setBackgroundColor:[UIColor darkGrayColor]];
        //[self setBackgroundColor:[UIColor colorWithRed:192.0/255.0 green:192.0/255.0 blue:192.0/255.0 alpha:1]];
        //[self setBackgroundColor:[UIColor silver]];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
