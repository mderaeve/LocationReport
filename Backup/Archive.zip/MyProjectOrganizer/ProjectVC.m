//
//  ProjectVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 08/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "ProjectVC.h"
#import "AUProject.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "ImageThumbView.h"

@interface ProjectVC ()
@property (strong, nonatomic) UIImage * img;
@end



@implementation ProjectVC
{
    bool isBrowse;
    VariableStore * store;
    NSMutableArray * picturesForProject;
    ALAssetsLibrary* assetslibrary;
    bool showZones;
    NSArray * zonesArray;
    NSDate * selectedDate;
}

@synthesize popoverController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    store = [VariableStore sharedInstance];
    showZones=NO;
    assetslibrary = [[ALAssetsLibrary alloc] init];
    // Do any additional setup after loading the view.
    [self initVars];

    if (store.selectedProject != nil)
    {
        [self setTitle:store.selectedProject.proj_title];
        showZones=YES;
    }
    else
    {
        [self setTitle:[[VariableStore sharedInstance] Translate:@"$PO$NewProject"]];
    }
    [self refresh];
    [self InitDatePicker];
    [self showDate];
    [self.btnShowZones setToSelected];
    
}

-(void)viewDidAppear:(BOOL)animated
{
    if( showZones==NO)
    {
        [self GetPicturesForProject];
    }
    else
    {
        [self GetZonesForProject];
    }
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self.colProjects performBatchUpdates:nil completion:nil];
}

-(void) InitDatePicker
{
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    [datePicker addTarget:self action:@selector(datePickerValueChanged:) forControlEvents:UIControlEventValueChanged];
    datePicker.tag = 1;
    if (store.selectedProject != nil)
    {
        datePicker.date = store.selectedProject.proj_date;
        selectedDate = store.selectedProject.proj_date;
    }
    else
    {
        selectedDate = [NSDate date];
    }
    datePicker.date = selectedDate;
    self.txtProjectDate.inputView = datePicker;
}

-(void)datePickerValueChanged:(id) datePicker
{
    selectedDate = ((UIDatePicker *)datePicker).date;
    [self showDate];
}

-(void) showDate
{
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"dd/MM/yyyy"];
    self.txtProjectDate.text = [formatter stringFromDate:selectedDate];
    [self.txtProjectDate resignFirstResponder];
}

- (IBAction)btnShowZones:(id)sender
{
    showZones=YES;
    [self.colProjects reloadData];
    [self.btnShowPictures setToDeselected];
    [self.btnShowZones setToSelected];
}

- (IBAction)btnShowPictures:(id)sender
{
    [self GetPicturesForProject];
    showZones=NO;
    //[self.colProjects reloadData];
    [self.btnShowPictures setToSelected];
    [self.btnShowZones setToDeselected];
}

- (IBAction)btnNewZone:(id)sender
{
    [VariableStore sharedInstance].selectedZone = nil;
    [self performSegueWithIdentifier:@"EditZone" sender:self];
}

-(void) initVars
{
    isBrowse=NO;
}

-(void) refresh
{
    if (store.selectedProject)
    {
        self.txtTitle.text = store.selectedProject.proj_title;
        self.txtInfo.text = store.selectedProject.proj_info;
        self.btnBrowsePicture.hidden=NO;
        self.btnTakePicture.hidden=NO;
        if( showZones==NO)
        {
            [self GetPicturesForProject];
        }
        self.vwDetails.hidden=NO;
    }
    else
    {
        self.btnBrowsePicture.hidden=YES;
        self.btnTakePicture.hidden=YES;
        picturesForProject=nil;
        zonesArray=nil;
        [self.colProjects reloadData];
        self.vwDetails.hidden=YES;
    }
}

#pragma mark Zones

-(void) GetZonesForProject
{
    if ([VariableStore sharedInstance].selectedProject!=nil)
    {
        zonesArray=nil;
        [self getZonesArray];
        [self.colProjects reloadData];
    }
}

-(NSArray *) getZonesArray
{
    if (zonesArray==nil)
    {
        zonesArray = [DBStore GetAllZones:[VariableStore sharedInstance].selectedProject.proj_id];
    }
    return zonesArray;
}

#pragma mark Pictures

-(void) GetPicturesForProject
{
    if (store.selectedProject.pic_id && [store.selectedProject.pic_id intValue] > 0)
    {
        picturesForProject = [NSMutableArray arrayWithArray:[DBStore GetPicturesID:store.selectedProject.pic_id]];
    }
    [self.colProjects reloadData];
}

#pragma CollectionView
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (showZones)
    {
        return [self getZonesArray].count;
    }
    else
    {
        return picturesForProject.count;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout  *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showZones==YES)
    {
        // Adjust cell size for orientation
        if (UIDeviceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
            return CGSizeMake(850, 65.0f);
        }
        return CGSizeMake(700, 65.0f);
    }
    else
    {
        return CGSizeMake(200, 200);
    }
}

-(UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showZones==YES)
    {
        ZoneCell  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ZoneCell" forIndexPath:indexPath];
        AUZone * zone = [[self getZonesArray] objectAtIndex:indexPath.row];
        cell.lblTitle.text = zone.z_title;
        return cell;
    }
    else
    {
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);
        
        
        ImageThumbView  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ImageCell" forIndexPath:indexPath];
        
        AUPicture * p = [picturesForProject objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            //ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [myasset thumbnail];//[rep fullResolutionImage];
            UIImage *im;
            if (iref)
            {
                @try {
                    //im = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    im = [UIImage imageWithCGImage:iref];
                    [cell.imgImage setImage:im];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }
        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
        [GeneralFunctions MakeSimpleRoundView:cell];
        cell.delegate = self;
        cell.pic = p;
        return cell;
    }
}

-(void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(showZones==YES)
    {
        AUZone * selectedZone = [zonesArray objectAtIndex:indexPath.row];
        store.selectedZone = selectedZone;
        [self performSegueWithIdentifier:@"EditZone" sender:self];
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(showZones==NO)
    {
        ImageThumbView * cell = (ImageThumbView *)[collectionView cellForItemAtIndexPath:indexPath];
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);

        AUPicture * p = [picturesForProject objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [rep fullResolutionImage];

            if (iref)
            {
                @try {
                    self.img = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    [StoryBoardNavigation NavigateToChangePictureStoryboard:self AndPicture:self.img AndPictureObject:cell.pic];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }
        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
    }
}

#pragma mark button events

- (IBAction)btnSaveProject:(id)sender
{
    if (![self.txtTitle.text isEqualToString:@""])
    {
        if( store.selectedProject)
        {
            //save project
            store.selectedProject.proj_info  = self.txtInfo.text;
            store.selectedProject.proj_title = self.txtTitle.text;
            store.selectedProject.proj_date = selectedDate;
            [DBStore SaveContext];
        }
        else
        {
            //create the project
            store.selectedProject = [DBStore CreateProject:self.txtTitle.text AndInfo:self.txtInfo.text AndDate:selectedDate];
            [self refresh];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[store Translate:@"$PO$Warning"] message:[store Translate:@"$PO$NoTitleProvided"] delegate:self cancelButtonTitle:[store Translate:@"$PO$OK"] otherButtonTitles: nil];
        [alert show];
    }
}

#pragma mark pictures

- (IBAction)btnTakePicture:(id)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.allowsEditing = NO;
        imagePicker.modalInPopover=YES;
        imagePicker.modalPresentationStyle = UIModalPresentationFullScreen;
        
        [self presentViewController:imagePicker animated:YES completion:nil];
        
        isBrowse = NO;
    }
    else
    {
        [self BrowsePictures];
    }

}

- (IBAction)btnBrowsePicture:(id)sender
{
    [self BrowsePictures];
}

-(void)BrowsePictures
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    
    self.popoverController = [[UIPopoverController alloc]
                              initWithContentViewController:imagePicker];
    
    self.popoverController.delegate = self;
    [self.popoverController setPopoverContentSize:CGSizeMake(500, 500)];
    
    
    UIView *tempView = self.view;
    CGPoint point = CGPointMake(tempView.frame.size.width/2,
                                tempView.frame.size.height/2);
    CGSize size = CGSizeMake(100, 100);
    [self.popoverController presentPopoverFromRect:
     CGRectMake(point.x, point.y, size.width, size.height)
                                            inView:self.view
                          permittedArrowDirections:UIPopoverArrowDirectionAny
                                          animated:YES];
    isBrowse=YES;
}

-(void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info
                      objectForKey:UIImagePickerControllerOriginalImage];
    if (isBrowse==NO)
    {
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        //ALAssetsLibrary *library = [Utils defaultAssetsLibrary];
        [library writeImageToSavedPhotosAlbum:image.CGImage orientation:(ALAssetOrientation)image.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error )
         {
             [self SavePictureIDforURL:[NSString stringWithFormat:@"%@", assetURL]];
             
         }];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        NSString * url = @"";
        url = [[info objectForKey:UIImagePickerControllerReferenceURL] absoluteString];
        [self SavePictureIDforURL:url];
        
        [self.popoverController dismissPopoverAnimated:true];
        isBrowse=NO;
    }
}

-(void) SavePictureIDforURL:(NSString *) url
{
    
    if (!store.selectedProject.pic_id || [store.selectedProject.pic_id intValue] == 0)
    {
        AUPicture * pic = [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:nil];
        store.selectedProject.pic_id = pic.pic_id;
    }
    else
    {
        [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:store.selectedProject.pic_id];
    }
    [DBStore SaveContext];
    [self GetPicturesForProject];
}

-(void) PictureDeleted
{
    [self GetPicturesForProject];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
