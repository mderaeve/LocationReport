//
//  PropertyCell.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 25/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "PropertyCell.h"

@implementation PropertyCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    
        [GeneralFunctions MakeCollViewCell:self];
    }
return self;
}

-(void) awakeFromNib
{
    [GeneralFunctions MakeCollViewCell:self];
}

- (IBAction)touchDownInTextField:(id)sender
{
    /*if ([self.delegate respondsToSelector:@selector(StartTypingInEdit)])
    {
        [self.delegate StartTypingInEdit];
    }*/
}


- (IBAction)btnDelete:(id)sender
{
    //Delete the property
    if (self.prop)
    {
        [DBStore DeleteProperty:self.prop];
        if ([self.delegate respondsToSelector:@selector(PropertyDeleted)])
        {
            [self.delegate PropertyDeleted];
        }
    }
}

@end
