//
//  NAVButton.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 14/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "NAVButton.h"

@implementation NAVButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}



@end
