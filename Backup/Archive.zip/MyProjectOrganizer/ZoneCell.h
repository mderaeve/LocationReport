//
//  ZoneCell.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 21/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZoneCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@property (weak, nonatomic) IBOutlet UILabel *lblInfo;
@end
