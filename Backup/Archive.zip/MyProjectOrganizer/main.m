//
//  main.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 01/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "POAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([POAppDelegate class]));
    }
}
