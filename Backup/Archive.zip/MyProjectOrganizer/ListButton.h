//
//  GPGListButton.h
//  GalvaSFIApp
//
//  Created by Mark Deraeve on 11/03/14.
//  Copyright (c) 2014 Galva Power. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListButton : UIButton

@end
