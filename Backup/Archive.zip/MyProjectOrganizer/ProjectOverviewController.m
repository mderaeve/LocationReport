//
//  ProjectOverviewController.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 23/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "ProjectOverviewController.h"

@implementation ProjectOverviewController

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id) init
{
    NSArray * subviewArray = [[NSBundle mainBundle] loadNibNamed:@"ProjectOverviewControl" owner:self options:nil];
    id mainView = [subviewArray objectAtIndex:0];
    if ([mainView isKindOfClass:[ProjectOverviewController class]])
    {
        [GeneralFunctions MakeRoundView:mainView];
        return mainView;
    }
    else
    {
        return nil;
    }
}

@end
