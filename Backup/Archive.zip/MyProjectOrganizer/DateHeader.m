//
//  DateHeader.m
//  LocationReport
//
//  Created by Mark Deraeve on 31/08/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "DateHeader.h"

@implementation DateHeader

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
