//
//  HomeVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "HomeVC.h"
#import "Button.h"
#import "ProjectOverviewController.h"

@interface HomeVC ()

@end

@implementation HomeVC
{
    /*Button * btnDetails;
    bool up;
    ProjectOverviewController * ph;*/
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [GeneralFunctions TranslateView:self.view];
    //Add the overview button at the bottom
    /*btnDetails = [[Button alloc] init];
    btnDetails.frame = CGRectMake(0.0, 0.0, 60, 60);
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    [self setDetailButtonFrame:orientation AndStart:YES];
    [btnDetails setTitle:@"" forState:UIControlStateNormal];
    [btnDetails setImage:[UIImage imageNamed:@"Up.png"] forState:UIControlStateNormal];
    [btnDetails addTarget:self action:@selector(buttonPushed) forControlEvents:UIControlEventTouchDown];
    
    ph = [[ProjectOverviewController alloc] init];
    [self setPanelFrame:orientation AndStart:YES];
    
    
    [self.view addSubview:ph];
   
    [self.view addSubview:btnDetails];
    
    up=NO;*/
}

/*
- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    [self setDetailButtonFrame:fromInterfaceOrientation AndStart:NO];
    [self setPanelFrame:fromInterfaceOrientation AndStart:NO];
    //UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    //[self setDetailButtonFrame:orientation];
}

-(void) setDetailButtonFrame:(UIInterfaceOrientation)fromInterfaceOrientation AndStart:(bool)start
{
    //Change the buttons frame
    
    if ((UIInterfaceOrientationIsPortrait(fromInterfaceOrientation) && start == NO) || (UIInterfaceOrientationIsLandscape(fromInterfaceOrientation) && start == YES))
    {
        float x = ([UIScreen mainScreen].bounds.size.height / 2) - 50;
        float y = [UIScreen mainScreen].bounds.size.width;
        y = y - 120;
        [btnDetails setFrame:CGRectMake(x, y, btnDetails.frame.size.width, btnDetails.frame.size.height)];
    }
    else
    {
        float x = ([UIScreen mainScreen].bounds.size.width / 2) - 50;
        float y = [UIScreen mainScreen].bounds.size.height;
        y = y - [UIApplication sharedApplication].statusBarFrame.size.height-100;
        [btnDetails setFrame:CGRectMake(x, y, btnDetails.frame.size.width, btnDetails.frame.size.height)];
    }
}

-(void) setPanelFrame:(UIInterfaceOrientation)fromInterfaceOrientation AndStart:(bool)start
{
    if ((UIInterfaceOrientationIsPortrait(fromInterfaceOrientation) && start == NO) || (UIInterfaceOrientationIsLandscape(fromInterfaceOrientation) && start == YES))
    {
        float x = ([UIScreen mainScreen].bounds.size.height / 2) - 50;
        float y = [UIScreen mainScreen].bounds.size.width;
        y = y - 120;
        [ph setFrame:CGRectMake(x, y, ph.frame.size.width, ph.frame.size.height)];
    }
    else
    {
        float x = ([UIScreen mainScreen].bounds.size.width / 2) - 50;
        float y = [UIScreen mainScreen].bounds.size.height;
        y = y - [UIApplication sharedApplication].statusBarFrame.size.height-100;
        [ph setFrame:CGRectMake(x, y, ph.frame.size.width, ph.frame.size.height)];
    }
}

-(void) buttonPushed
{
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    //Show the details view
    if (up==YES)
    {
        [btnDetails setImage:[UIImage imageNamed:@"Up.png"] forState:UIControlStateNormal];
        up=NO;
    }
    else
    {
        [btnDetails setImage:[UIImage imageNamed:@"Down.png"] forState:UIControlStateNormal];
        up=YES;
    }
}
*/
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidLoad];
    self.homeMenu = [[HomeMenuVC alloc] init];
    [self.homeMenu CreateMenu:self];
}

@end
