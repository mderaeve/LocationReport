//
//  SubZoneTypesVC.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 25/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SubZoneTypeCell.h"
#import "PropertyCell.h"

@interface SubZoneTypesVC : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate,PropertyCellDelegate, SubZoneTypeCellDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *colTypes;
@property (weak, nonatomic) IBOutlet UICollectionView *colProperties;

@end
