//
//  ZoneVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 15/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "ZoneVC.h"
#import "AUZone.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "ImageThumbView.h"

@interface ZoneVC ()
@property (strong, nonatomic) UIImage * img;
@end

@implementation ZoneVC
{
    bool isBrowse;
    VariableStore * store;
    NSMutableArray * picturesForZone;
    ALAssetsLibrary* assetslibrary;
    NSArray * subZonesArray;
    bool showZones;
}

@synthesize popoverController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    store = [VariableStore sharedInstance];
    assetslibrary = [[ALAssetsLibrary alloc] init];
    showZones=NO;
    if (store.selectedZone != nil)
    {
        [self setTitle:store.selectedZone.z_title];
        showZones=YES;
    }
    else
    {
        [self setTitle:[[VariableStore sharedInstance] Translate:@"$PO$NewZone"]];
    }
    // Do any additional setup after loading the view.
    [self initVars];
    [self refresh];
    
    [self.btnShowSubZones setToSelected];
}

-(void) viewDidAppear:(BOOL)animated
{
    if( showZones==NO)
    {
        [self GetPicturesForZone];
    }
    else
    {
        [self GetSubZonesForZone];
    }
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self.colPictures performBatchUpdates:nil completion:nil];
}

-(void) initVars
{
    isBrowse=NO;
}

-(void) refresh
{
    if (store.selectedZone)
    {
        self.txtProjectTitle.text = store.selectedProject.proj_title;
        self.txtTitle.text = store.selectedZone.z_title;
        self.txtDescription.text = store.selectedZone.z_info;
        self.vwDetails.hidden=NO;
        [self GetPicturesForZone];
    }
    else
    {
        self.txtProjectTitle.text = store.selectedProject.proj_title;
        self.vwDetails.hidden=YES;
    }
}

- (IBAction)btnPictures:(id)sender
{
    showZones=NO;
    [self.colPictures reloadData];
    [self.btnShowPictures setToSelected];
    [self.btnShowSubZones setToDeselected];

}

- (IBAction)btnSubZones:(id)sender
{
    showZones=YES;
    [self.colPictures reloadData];
    [self.btnShowPictures setToDeselected];
    [self.btnShowSubZones setToSelected];
}

#pragma mark subzones

-(void) GetSubZonesForZone
{
    if ([VariableStore sharedInstance].selectedZone!=nil)
    {
        subZonesArray=nil;
        [self getSubZonesArray];
        [self.colPictures reloadData];
    }
}


-(NSArray *) getSubZonesArray
{
    if (subZonesArray==nil)
    {
        subZonesArray = [DBStore GetAllSubZones:[VariableStore sharedInstance].selectedZone.z_id];
    }
    return subZonesArray;
}

#pragma mark Pictures

-(void) GetPicturesForZone
{
    if (store.selectedZone.pic_id && [store.selectedZone.pic_id intValue] > 0)
    {
        picturesForZone = [NSMutableArray arrayWithArray:[DBStore GetPicturesID:store.selectedZone.pic_id]];
    }
    [self.colPictures reloadData];
}

#pragma CollectionView
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (showZones==YES)
    {
        return [self getSubZonesArray].count;
    }
    else
    {
        return picturesForZone.count;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout  *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showZones==YES)
    {
        // Adjust cell size for orientation
        if (UIDeviceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
            return CGSizeMake(850, 65.0f);
        }
        return CGSizeMake(700, 65.0f);
    }
    else
    {
        return CGSizeMake(200, 200);
    }
}

-(UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showZones==YES)
    {
        SubZonesCell  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SubZonesCell" forIndexPath:indexPath];
        AUSubZone * subZone = [[self getSubZonesArray] objectAtIndex:indexPath.row];
        cell.lblTitle.text = subZone.sz_title;
        return cell;
    }
    else
    {
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);
        
        
        ImageThumbView  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ImageCell" forIndexPath:indexPath];
        
        AUPicture * p = [picturesForZone objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            //ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [myasset thumbnail];//[rep fullResolutionImage];
            UIImage *im;
            if (iref)
            {
                @try {
                    //im = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    im = [UIImage imageWithCGImage:iref];
                    [cell.imgImage setImage:im];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }

        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
        [GeneralFunctions MakeSimpleRoundView:cell];
        cell.pic = p;
        cell.delegate = self;
        return cell;
    }
}

-(void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(showZones==YES)
    {
        //Move to zones
        //[self performSegueWithIdentifier:@"MoveToSubZone" sender:self];
        AUSubZone * selectedSubZone = [subZonesArray objectAtIndex:indexPath.row];
        store.selectedSubZone = selectedSubZone;
        [self performSegueWithIdentifier:@"EditSubZone" sender:self];
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(showZones==NO)
    {
        ImageThumbView * cell = (ImageThumbView *)[collectionView cellForItemAtIndexPath:indexPath];
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);
        
        AUPicture * p = [picturesForZone objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [rep fullResolutionImage];
            
            if (iref)
            {
                @try {
                    self.img = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    [StoryBoardNavigation NavigateToChangePictureStoryboard:self AndPicture:self.img AndPictureObject:cell.pic];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }
        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
    }
}

- (IBAction)btnSaveZone:(id)sender
{
    if (![self.txtTitle.text isEqualToString:@""])
    {
        if( store.selectedZone)
        {
            //save project
            store.selectedZone.z_info  = self.txtDescription.text;
            store.selectedZone.z_title = self.txtTitle.text;
            store.selectedZone.proj_id = store.selectedProject.proj_id;
            [DBStore SaveContext];
        }
        else
        {
            //create the project
            store.selectedZone = [DBStore CreateZone:self.txtTitle.text AndInfo:self.txtDescription.text AndProjectID:store.selectedProject.proj_id];
            [self refresh];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[store Translate:@"$PO$Warning"] message:[store Translate:@"$PO$NoTitleProvided"] delegate:self cancelButtonTitle:[store Translate:@"$PO$OK"] otherButtonTitles: nil];
        [alert show];
    }
}

- (IBAction)btnTakePicture:(id)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.allowsEditing = NO;
        imagePicker.modalInPopover=YES;
        imagePicker.modalPresentationStyle = UIModalPresentationFullScreen;
        
        [self presentViewController:imagePicker animated:YES completion:nil];
        
        isBrowse = NO;
    }
    else
    {
        [self BrowsePictures];
    }
}

- (IBAction)btnBrowsePicture:(id)sender
{
    [self BrowsePictures];
}

-(void)BrowsePictures
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    
    self.popoverController = [[UIPopoverController alloc]
                              initWithContentViewController:imagePicker];
    
    self.popoverController.delegate = self;
    [self.popoverController setPopoverContentSize:CGSizeMake(500, 500)];
    
    
    UIView *tempView = self.view;
    CGPoint point = CGPointMake(tempView.frame.size.width/2,
                                tempView.frame.size.height/2);
    CGSize size = CGSizeMake(100, 100);
    [self.popoverController presentPopoverFromRect:
     CGRectMake(point.x, point.y, size.width, size.height)
                                            inView:self.view
                          permittedArrowDirections:UIPopoverArrowDirectionAny
                                          animated:YES];
    isBrowse=YES;
}

-(void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info
                      objectForKey:UIImagePickerControllerOriginalImage];
    if (isBrowse==NO)
    {
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        //ALAssetsLibrary *library = [Utils defaultAssetsLibrary];
        [library writeImageToSavedPhotosAlbum:image.CGImage orientation:(ALAssetOrientation)image.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error )
         {
             [self SavePictureIDforURL:[NSString stringWithFormat:@"%@", assetURL]];
             
         }];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        NSString * url = @"";
        url = [[info objectForKey:UIImagePickerControllerReferenceURL] absoluteString];
        [self SavePictureIDforURL:url];
        
        [self.popoverController dismissPopoverAnimated:true];
        isBrowse=NO;
        //[self Upload:self andTry:0 andImage:image];
    }
    
    //save the image to the library and couple it to the project.
    
}

#pragma mark pictures

-(void) PictureDeleted
{
    [self GetPicturesForZone];
}

-(void) SavePictureIDforURL:(NSString *) url
{
    
    if (!store.selectedZone.pic_id || [store.selectedZone.pic_id intValue] == 0)
    {
        AUPicture * pic = [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:nil];
        store.selectedZone.pic_id = pic.pic_id;
    }
    else
    {
        [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:store.selectedZone.pic_id];
    }
    [DBStore SaveContext];
    [self GetPicturesForZone];
}

- (IBAction)btnNewSubZone:(id)sender
{
    [VariableStore sharedInstance].selectedSubZone = nil;
    [self performSegueWithIdentifier:@"EditSubZone" sender:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
