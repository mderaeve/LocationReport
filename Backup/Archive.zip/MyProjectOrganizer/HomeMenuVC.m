//
//  HomeMenuVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//
#import "HomeMenuVC.h"
#import "HomeMenuVC.h"

@interface HomeMenuVC ()

@end

@implementation HomeMenuVC
{
    LeveyPopListView *lplv;
    bool bListOpen;
    UIViewController * senderVC;
}

-(void) CreateMenu: (UIViewController *) sender
{
    bListOpen=NO;
    [self FillShortMenuOptions];
    
    UIBarButtonItem * home = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"house.png"] style:UIBarButtonItemStylePlain target:self action:@selector(handleHomeButton:)];
    sender.navigationItem.rightBarButtonItem = home;
    senderVC = sender;
}

-(void) handleHomeButton:(id) sender
{
    if (!bListOpen)
    {
        
        if ([senderVC.view isKindOfClass:[UIScrollView class]])
        {
            //Scroll the top scrolview to the top
            ((UIScrollView *)senderVC.view).contentOffset = CGPointMake(0,0);
        }

        bListOpen=YES;
        VariableStore * store = [VariableStore sharedInstance];
        lplv = [[LeveyPopListView alloc] initWithTitle:[store Translate:@"$MOB$Menu"] options:store.OptionsToSet headerImage:@"house.png"];
        lplv.delegate=self;
        [lplv showInView:senderVC.view animated:YES];
    }
    else
    {
        bListOpen=NO;
        [lplv removeFromSuperview];
    }
}

#pragma mark - LeveyPopListView Filler
-(void) FillShortMenuOptions
{
    if (![VariableStore sharedInstance].OptionsToSet)
    {
        NSMutableArray * optionsToSet = [[NSMutableArray alloc] init];
        /*for (NSString * label in store.MESHomeButtonsArray)
         {
         UIImage * image = [UIImage imageNamed:@"73-radar.png"];
         [optionsToSet addObject:[NSDictionary dictionaryWithObjectsAndKeys:image,@"img",label,@"text", nil]];
         }*/
        [optionsToSet addObject:[NSDictionary dictionaryWithObjectsAndKeys:[UIImage imageNamed:@"house.png"],@"img",[[VariableStore sharedInstance] Translate:@"$PO$Home"],@"text", nil]];
        [optionsToSet addObject:[NSDictionary dictionaryWithObjectsAndKeys:[UIImage imageNamed:@"navigation.png"],@"img",[[VariableStore sharedInstance] Translate:@"$PO$Cancel"],@"text", nil]];
        [VariableStore sharedInstance].OptionsToSet = [NSArray arrayWithArray:optionsToSet];
    }
}

#pragma mark - LeveyPopListView delegates
- (void)leveyPopListView:(LeveyPopListView *)popListView didSelectedIndex:(NSInteger)anIndex
{
    bListOpen=NO;
    NSDictionary * item = [VariableStore sharedInstance].OptionsToSet[anIndex];
    NSString * itemText = item[@"text"];
    if ([itemText isEqualToString:[[VariableStore sharedInstance] Translate:@"$PO$Cancel"]])
    {
        [popListView removeFromSuperview];
        return;
    }
    else if ([itemText isEqualToString:[[VariableStore sharedInstance] Translate:@"$PO$Home"]])
    {
        //[senderVC.navigationController popViewControllerAnimated:YES];
        [senderVC.navigationController popToRootViewControllerAnimated:YES];
    }
}
- (void)leveyPopListViewDidCancel
{
    bListOpen=NO;
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        VariableStore * store = [VariableStore sharedInstance];
        store.selectedProject = nil;
        store.selectedZone = nil;
        [senderVC dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
