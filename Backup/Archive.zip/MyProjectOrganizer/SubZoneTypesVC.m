//
//  SubZoneTypesVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 25/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "SubZoneTypesVC.h"

@interface SubZoneTypesVC ()

@end

@implementation SubZoneTypesVC
{
    NSArray * subZoneTypesArray;
    NSArray * propertiesArray;
    //SubZoneTypes * selectedSubType;
    SubZoneTypeCell  * selectedCell;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [GeneralFunctions TranslateView:self.view];
    // Do any additional setup after loading the view.
    //subZoneTypesArray = [DBStore GetAllSubZoneTypes];
    propertiesArray = [[NSArray alloc] init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) fillProperties
{
   // propertiesArray = [DBStore GetAllPropertyTemplatesForSubZoneType:selectedSubType.subzonetype_id];
    [self.colProperties reloadData];
}

#pragma mark PropertyTemplate

-(void) PropertyDeleted
{
    [self fillProperties];
}

-(void) StartTypingInEdit
{
    //nothing
}

#pragma mark SubZoneType

-(void) TypeDeleted
{
   // subZoneTypesArray = [DBStore GetAllSubZoneTypes];
    [self.colTypes reloadData];
}

#pragma mark CollectionView
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (collectionView == self.colTypes)
    {
        return subZoneTypesArray.count;
    }
    else
    {
        return propertiesArray.count;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout  *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(687.0f, 65.0f);
}

-(UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.colTypes)
    {
        SubZoneTypeCell  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SubZoneTypeCell" forIndexPath:indexPath];
        //SubZoneTypes * subZoneType = [subZoneTypesArray objectAtIndex:indexPath.row];
        //cell.txtTitle.text = subZoneType.title;
        //cell.subZoneType = subZoneType;
        cell.delegate = self;
        /*[GeneralFunctions TranslateView:cell];
        if (subZoneType == selectedSubType)
        {
            [cell setBackgroundColor:[UIColor blueColor]];
        }
        else
        {
            [cell setBackgroundColor:[UIColor redColor]];
        }*/
        return cell;
    }
    else
    {
        PropertyCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PropertyCell" forIndexPath:indexPath];
        AUPropertyTemplate * temp = [propertiesArray objectAtIndex:indexPath.row];
        cell.delegate   = self;
        //cell.temp = temp;
        [GeneralFunctions TranslateView:cell];
        cell.txtValue.text = temp.templ_title;
        return cell;
    }
}

- (void) collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.colTypes)
    {
        if (selectedCell)
        {
            [selectedCell setBackgroundColor:[UIColor redColor]];
        }
        /*SubZoneTypes * subZoneType = [subZoneTypesArray objectAtIndex:indexPath.row];
        selectedSubType = subZoneType;
        [self fillProperties];
       
        SubZoneTypeCell *cell = (SubZoneTypeCell *)[collectionView cellForItemAtIndexPath:indexPath];
        selectedCell = cell;
        [cell setBackgroundColor:[UIColor blueColor]];*/
        
    }
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
