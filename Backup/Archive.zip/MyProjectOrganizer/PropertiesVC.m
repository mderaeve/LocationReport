//
//  PropertiesVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 28/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "PropertiesVC.h"
#import "AUProperty.h"


@interface PropertiesVC ()

@end

@implementation PropertiesVC
{
    NSArray * propertiesArray;
    VariableStore * store;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    store = [VariableStore sharedInstance];
    //Fill properties
    //propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self.colProperties reloadData];
}

-(void) PropertAdded
{
    //propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self.colProperties reloadData];
}

-(void) PropertyDeleted
{
   // propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self.colProperties reloadData];
}

-(void) StartTypingInEdit
{
    //raiseview
}

-(void) StartTypingInNew
{
    //raiseview
}

#pragma mark CollectionView
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}

-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 1)
    {
        return propertiesArray.count;
    }
    else
    {
        return 1;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout  *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
        if (UIDeviceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
            return CGSizeMake(980, 54.0f);
        }
        return CGSizeMake(762, 54.0f);
}

-(UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
   
        if (indexPath.section==1)
        {
            PropertyCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PropertyCell" forIndexPath:indexPath];
            AUProperty * property = [propertiesArray objectAtIndex:indexPath.row];
            cell.lblProperty.text = property.prop_title;
            cell.txtValue.text    = property.prop_value;
            cell.delegate = self;
            cell.prop = property;
            return cell;
        }
        else
        {
            PropertyNewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PropertyNewCell" forIndexPath:indexPath];
            cell.delegate = self;
            return cell;
        }
    
}

-(void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    
        AUProperty * p = [propertiesArray objectAtIndex:indexPath.row];
        [VariableStore sharedInstance].selectedProperty = p;
    
    
}

-(void)collectionView:(UICollectionView *)collectionView didUnhighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
