//
//  ZoneVC.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 15/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Button.h"
#import "SubZonesCell.h"
#import "ImageThumbView.h"
#import "Button+Layout.h"

@interface ZoneVC : HomeVC <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, PictureDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtProjectTitle;
@property (weak, nonatomic) IBOutlet UITextField *txtTitle;
@property (weak, nonatomic) IBOutlet UITextView *txtDescription;
@property (weak, nonatomic) IBOutlet UISwitch *cbxUploaded;
@property (nonatomic, retain) UIPopoverController   *popoverController;
@property (weak, nonatomic) IBOutlet Button *btnShowSubZones;
@property (weak, nonatomic) IBOutlet Button *btnShowPictures;

@property (weak, nonatomic) IBOutlet UICollectionView *colPictures;
@property (weak, nonatomic) IBOutlet Button *btnSave;

@property (weak, nonatomic) IBOutlet UIView *vwDetails;

@end
