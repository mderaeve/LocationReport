//
//  ProjectVC.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 08/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Button.h"
#import "ImageThumbView.h"
#import "ZoneCell.h"
#import "Button+Layout.h"

@interface ProjectVC : HomeVC <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, PictureDelegate>
@property (weak, nonatomic) IBOutlet UITextField *txtTitle;
@property (weak, nonatomic) IBOutlet UITextView *txtInfo;
@property (weak, nonatomic) IBOutlet UISwitch *cbxUploeded;
@property (nonatomic, retain) UIPopoverController   *popoverController;

@property (weak, nonatomic) IBOutlet UITextField *txtProjectDate;
@property (weak, nonatomic) IBOutlet Button *btnShowZones;
@property (weak, nonatomic) IBOutlet Button *btnShowPictures;

@property (weak, nonatomic) IBOutlet Button *btnTakePicture;
@property (weak, nonatomic) IBOutlet Button *btnBrowsePicture;

@property (weak, nonatomic) IBOutlet UICollectionView *colProjects;
@property (weak, nonatomic) IBOutlet UIView *vwDetails;

@end
