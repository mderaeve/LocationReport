//
//  SubZoneType.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 25/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SubZoneTypeCellDelegate <NSObject>

-(void) TypeDeleted;

@end

@interface SubZoneTypeCell: UICollectionViewCell <UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtTitle;
//@property (strong, nonatomic) SubZoneTypes * subZoneType;

@property (strong, nonatomic) id delegate;

@end
