//
//  SubZonesVC.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "HomeVC.h"
#import "Button.h"
#import "ImageThumbView.h"
#import "PropertyCell.h"
#import "PropertyNewCell.h"
#import "Button+Layout.h"
#import "ObjectPicker.h"

@interface SubZonesVC : HomeVC <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, PictureDelegate, PropertyCellDelegate, NewPropertyDelegate,UITextViewDelegate, UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet Button *btnSaveSubZone;

@property (weak, nonatomic) IBOutlet UIView *vwDetails;

@property (weak, nonatomic) IBOutlet Button *btnSearchTypes;
@property (weak, nonatomic) IBOutlet Button *btnSaveType;

@property (weak, nonatomic) IBOutlet Button *btnShowProperties;
@property (weak, nonatomic) IBOutlet Button *btnShowPictures;
@property (weak, nonatomic) IBOutlet UICollectionView *colPictures;

@property (weak, nonatomic) IBOutlet UITextField *lblProject;
@property (weak, nonatomic) IBOutlet UITextField *lblZone;
@property (weak, nonatomic) IBOutlet UITextField *txtTitle;
@property (weak, nonatomic) IBOutlet UITextView *txtInfo;
@property (weak, nonatomic) IBOutlet UISwitch *cbxUploaded;

@property (nonatomic, retain) UIPopoverController   *popoverController;

@property (weak, nonatomic) IBOutlet UITextField *txtType;

@end
