//
//  SubZoneType.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 25/05/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "SubZoneTypeCell.h"

@implementation SubZoneTypeCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (IBAction)btnDeleteClick:(id)sender
{
    //Delete the type together with the properties
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[[VariableStore sharedInstance] Translate:@"$PO$Warning"] message:[[VariableStore sharedInstance]  Translate:@"$PO$AreYouSureToDelete"] delegate:self cancelButtonTitle:[[VariableStore sharedInstance]  Translate:@"$PO$NO"] otherButtonTitles:[[VariableStore sharedInstance]  Translate:@"$PO$YES"], nil];
    [alert show];
}

-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex>0)
    {
        //[DBStore DeleteSubZoneType:self.subZoneType];
        if ([self.delegate respondsToSelector:@selector(TypeDeleted)])
        {
            [self.delegate TypeDeleted];
        }

    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
