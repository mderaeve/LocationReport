//
//  SubZonesVC.m
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 22/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "SubZonesVC.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "ImageThumbView.h"


@interface SubZonesVC ()
@property (strong, nonatomic) UIImage * img;
@end

@implementation SubZonesVC
{
    bool isBrowse;
    VariableStore * store;
    NSMutableArray * picturesForSubZone;
    ALAssetsLibrary* assetslibrary;
    NSArray * propertiesArray;
    bool showProperties;
    bool clickedInProperty;
    NSArray * subZoneTypes;
    NSNumber * selectedSubType;
}

@synthesize popoverController;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Do any additional setup after loading the view.
    store = [VariableStore sharedInstance];
    assetslibrary = [[ALAssetsLibrary alloc] init];
    showProperties=NO;
    clickedInProperty=NO;
    
    if (store.selectedSubZone != nil)
    {
        [self setTitle:store.selectedSubZone.sz_title];
        showProperties=YES;
    }
    else
    {
        [self setTitle:[[VariableStore sharedInstance] Translate:@"$PO$NewSubZone"]];
    }
    // Do any additional setup after loading the view.
    [self initVars];
    [self refresh];
    
    [self.btnShowProperties setToSelected];
}

-(void) viewDidAppear:(BOOL)animated
{
     [super viewDidAppear:animated];
   // propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self reloadPropertyData];
    //[self.colPictures performBatchUpdates:nil completion:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    // register for keyboard notifications
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    [self.colPictures performBatchUpdates:nil completion:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    // unregister for keyboard notifications while not visible.
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
}

-(void)keyboardWillShow
{
    if (clickedInProperty == YES)
    {
        // Animate the current view out of the way
        if (self.view.frame.origin.y >= 0)
        {
            [GeneralFunctions setViewMovedUp:YES AndView:self.view];
        }
        else if (self.view.frame.origin.y < 0)
        {
            //[GeneralFunctions setViewMovedUp:NO AndView:self.view];
            //screen is up
        }
    }
}

-(void)keyboardWillHide
{
    clickedInProperty=NO;
    if (self.view.frame.origin.y >= 0)
    {
        //Screen is =ok
    }
    else if (self.view.frame.origin.y < 0)
    {
        [GeneralFunctions setViewMovedUp:NO AndView:self.view];
    }
}

-(void) initVars
{
    isBrowse=NO;
}

- (IBAction)btnProperties:(id)sender
{
    showProperties=YES;
    [self reloadPropertyData];
    [self.btnShowPictures setToDeselected];
    [self.btnShowProperties setToSelected];
}

- (IBAction)btnPictures:(id)sender
{
    showProperties=NO;
    [self reloadPropertyData];
    [self.btnShowProperties setToDeselected];
    [self.btnShowPictures setToSelected];
}

- (IBAction)btnSearchType:(id)sender
{
    //subZoneTypes = [DBStore GetAllSubZoneTypes];
    //Show the types in a picker view
    [ObjectPicker showPickerWithTitle:[store Translate:@"$PO$SelectType"] rows:subZoneTypes initialSelection:0 target:self successAction:@selector(typeSelected:element:) cancelAction:nil origin:self.txtType descriptionField:@"sz_title"];
}

- (void)typeSelected:(NSNumber *)selectedIndex element:(id)textField
{
    if ([textField isKindOfClass:[UITextField class]])
    {
       /* SubZoneTypes * data = [subZoneTypes objectAtIndex:[selectedIndex intValue]];
        ((UITextField *)textField).text = data.title;
        //insert the properties.
        selectedSubType = data.subzonetype_id;*/
    }
}
- (IBAction)btnAddType:(id)sender
{
    //save the current type with properties as template, if exists, ask to overwrite.
   // SubZoneTypes * sbt = [DBStore GetSybZoneTypeByTitle:self.txtType.text];
    /*if (sbt)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[store Translate:@"$PO$Warning"] message:[store Translate:@"$PO$TypeAlreadyExistsOverwrite?"] delegate:self cancelButtonTitle:[store Translate:@"$PO$NO"] otherButtonTitles:[store Translate:@"$PO$YES"], nil];
        [alert show];
    }
    else
    {
        //add new
        SubZoneTypes * s = [DBStore CreateSubZoneType:self.txtType.text AndPropertiesForTemplate:propertiesArray];
        store.selectedSubZone.subzonetype_id = s.subzonetype_id;
        [DBStore SaveContext];
        //tell that its created
    }*/
}

- (IBAction)btnTypeChanged:(id)sender
{
    /*if ([self.txtType.text isEqualToString:@""] )
    {
        self.btnSaveType.hidden=YES;
    }
    else if (![self.txtType.text isEqualToString:@""] && store.selectedSubZone!=nil)
    {
        self.btnSaveType.hidden=NO;
    }*/
}


-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex>0)
    {
        /*SubZoneTypes * sbt = [DBStore GetSybZoneTypeByTitle:self.txtType.text];
        store.selectedSubZone.subzonetype_id = sbt.subzonetype_id;
        [DBStore SaveContext];
        //Overwrite
        [DBStore UpdateSubZoneTypeProperties:store.selectedSubZone.subzonetype_id AndPropertiesForTemplate:propertiesArray];*/
    }
}

-(void) refresh
{
    
    if (store.selectedSubZone!=nil)
    {
        [self setTitle:store.selectedSubZone.sz_title];
        self.lblProject.text = store.selectedProject.proj_title;
        self.lblZone.text = store.selectedZone.z_title;
        self.txtTitle.text = store.selectedSubZone.sz_title;
        self.txtInfo.text = store.selectedSubZone.sz_info;
        self.vwDetails.hidden=NO;
        [self GetPicturesForZone];
        /*if (store.selectedSubZone.subzonetype_id)
        {
            SubZoneTypes * type = [DBStore GetSybZoneTypeByID:store.selectedSubZone.subzonetype_id];
            self.txtType.text = type.title;
            selectedSubType = type.subzonetype_id;
        }*/
    }
    else
    {
        self.lblProject.text = store.selectedProject.proj_title;
        self.lblZone.text = store.selectedZone.z_title;
        self.vwDetails.hidden=YES;
    }
}

- (IBAction)btnSave:(id)sender
{
    if (![self.txtTitle.text isEqualToString:@""])
    {
        if( store.selectedSubZone)
        {
            //save project
            store.selectedSubZone.sz_info  = self.txtInfo.text;
            store.selectedSubZone.sz_title = self.txtTitle.text;
            store.selectedSubZone.z_id = store.selectedZone.z_id;
            //store.selectedSubZone.subzonetype_id = selectedSubType;
            [DBStore SaveContext];
        }
        else
        {
            //create the project
            store.selectedSubZone = [DBStore CreateSubZone:self.txtTitle.text AndInfo:self.txtInfo.text AndZoneID:store.selectedZone.z_id];
           // store.selectedSubZone.subzonetype_id = selectedSubType;
            [DBStore SaveContext];
        }
        //If there are no proerties, and there is a subtype selected, add the properties.
        if (propertiesArray==nil && propertiesArray.count==0 && ![self.txtType.text isEqualToString:@""])
        {
            /*NSArray * propertiesToAdd = [DBStore GetAllPropertyTemplatesForSubZoneType:selectedSubType];
            
            for (PropertyTemplate * t in propertiesToAdd)
            {
                [DBStore CreateProperty:t.title AndValue:@"" AndSubZoneID:store.selectedSubZone.subzone_id];
            }
            propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
            [self reloadPropertyData];*/
        }
        [self refresh];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[store Translate:@"$PO$Warning"] message:[store Translate:@"$PO$NoTitleProvided"] delegate:self cancelButtonTitle:[store Translate:@"$PO$OK"] otherButtonTitles: nil];
        [alert show];
    }
}

#pragma mark Pictures

-(void) GetPicturesForZone
{
    if (store.selectedSubZone.pic_id && [store.selectedSubZone.pic_id intValue] > 0)
    {
        picturesForSubZone = [NSMutableArray arrayWithArray:[DBStore GetPicturesID:store.selectedSubZone.pic_id]];
    }
    [self reloadPropertyData];
}

- (IBAction)btnTakePicture:(id)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        imagePicker.delegate = self;
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        imagePicker.allowsEditing = NO;
        imagePicker.modalInPopover=YES;
        imagePicker.modalPresentationStyle = UIModalPresentationFullScreen;
        
        [self presentViewController:imagePicker animated:YES completion:nil];
        
        isBrowse = NO;
    }
    else
    {
        [self BrowsePictures];
    }
}

- (IBAction)btnBrowse:(id)sender
{
    [self BrowsePictures];
}

-(void)BrowsePictures
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    
    self.popoverController = [[UIPopoverController alloc]
                              initWithContentViewController:imagePicker];
    
    self.popoverController.delegate = self;
    [self.popoverController setPopoverContentSize:CGSizeMake(500, 500)];
    
    
    UIView *tempView = self.view;
    CGPoint point = CGPointMake(tempView.frame.size.width/2,
                                tempView.frame.size.height/2);
    CGSize size = CGSizeMake(100, 100);
    [self.popoverController presentPopoverFromRect:
     CGRectMake(point.x, point.y, size.width, size.height)
                                            inView:self.view
                          permittedArrowDirections:UIPopoverArrowDirectionAny
                                          animated:YES];
    isBrowse=YES;
}

-(void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info
                      objectForKey:UIImagePickerControllerOriginalImage];
    if (isBrowse==NO)
    {
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        //ALAssetsLibrary *library = [Utils defaultAssetsLibrary];
        [library writeImageToSavedPhotosAlbum:image.CGImage orientation:(ALAssetOrientation)image.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error )
         {
             [self SavePictureIDforURL:[NSString stringWithFormat:@"%@", assetURL]];
             
         }];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        NSString * url = @"";
        url = [[info objectForKey:UIImagePickerControllerReferenceURL] absoluteString];
        [self SavePictureIDforURL:url];
        
        [self.popoverController dismissPopoverAnimated:true];
        isBrowse=NO;
        //[self Upload:self andTry:0 andImage:image];
    }
    
    //save the image to the library and couple it to the project.
    
}

#pragma mark pictures

-(void) PictureDeleted
{
    [self GetPicturesForZone];
}

-(void) SavePictureIDforURL:(NSString *) url
{
    
    if (!store.selectedSubZone.pic_id || [store.selectedSubZone.pic_id intValue] == 0)
    {
        AUPicture * pic = [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:nil];
        store.selectedSubZone.pic_id = pic.pic_id;
    }
    else
    {
        [DBStore CreatePicture:self.txtTitle.text AndURL:url AndComment:@"" AndPictureID:store.selectedSubZone.pic_id];
    }
    [DBStore SaveContext];
    [self GetPicturesForZone];
}

#pragma PropertyCEllDelegates implementation

-(void) PropertAdded
{
    //propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self reloadPropertyData];
}
 
-(void) PropertyDeleted
{
    //propertiesArray = [DBStore GetAllPropertiesForSubZone:store.selectedSubZone.subzone_id];
    [self reloadPropertyData];
}

-(void) StartTypingInEdit
{
    clickedInProperty=YES;
}

-(void) StartTypingInNew
{
    clickedInProperty=YES;
}

#pragma CollectionView
-(NSInteger) numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    if (showProperties==YES)
    {
        return 2;
    }
    else
    {
        return 1;
    }
}

-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (showProperties==YES)
    {
        if (section == 0)
        {
            return 1;
        }
        else
        {
            return propertiesArray.count;
        }
    }
    else
    {
        return picturesForSubZone.count;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout  *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showProperties==YES)
    {
        // Adjust cell size for orientation
        if (UIDeviceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation])) {
            return CGSizeMake(850, 65.0f);
        }
        return CGSizeMake(700, 65.0f);
    }
    else
    {
        return CGSizeMake(200, 200);
    }
}

-(UICollectionViewCell *) collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (showProperties==YES)
    {
        if (indexPath.section==1)
        {
            PropertyCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PropertyCell" forIndexPath:indexPath];
            AUProperty * property = [propertiesArray objectAtIndex:indexPath.row];
            cell.lblProperty.text = property.prop_title;
            cell.txtValue.text    = property.prop_value;
            cell.delegate = self;
            cell.prop = property;
            return cell;
        }
        else
        {
            PropertyNewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PropertyNewCell" forIndexPath:indexPath];
            cell.delegate = self;
            return cell;
        }
    }
    else
    {
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);
        
        
        ImageThumbView  * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ImageCell" forIndexPath:indexPath];
        
        AUPicture * p = [picturesForSubZone objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            //ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [myasset thumbnail];//[rep fullResolutionImage];
            UIImage *im;
            if (iref)
            {
                @try {
                    //im = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    im = [UIImage imageWithCGImage:iref];
                    [cell.imgImage setImage:im];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }
        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
        [GeneralFunctions MakeSimpleRoundView:cell];
        cell.pic = p;
        cell.delegate = self;
        return cell;
    }
}



-(void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if(showProperties==NO)
    {
        ImageThumbView * cell = (ImageThumbView *)[collectionView cellForItemAtIndexPath:indexPath];
        typedef void (^ALAssetsLibraryAssetForURLResultBlock)(ALAsset *asset);
        typedef void (^ALAssetsLibraryAccessFailureBlock)(NSError *error);
        
        AUPicture * p = [picturesForSubZone objectAtIndex:indexPath.row];
        
        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *myasset)
        {
            ALAssetRepresentation *rep = [myasset defaultRepresentation];
            CGImageRef iref = [rep fullResolutionImage];
            
            if (iref)
            {
                @try {
                    self.img = [UIImage imageWithCGImage:iref scale:[rep scale] orientation:(UIImageOrientation)[rep orientation]];
                    [StoryBoardNavigation NavigateToChangePictureStoryboard:self AndPicture:self.img AndPictureObject:cell.pic];
                }
                @catch (NSException *exception) {
                    NSLog(@"Exception:%@",exception);
                    [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
                }
            }
            else
            {
                [cell.imgImage setImage:[UIImage imageNamed:@"error.png"]];
            }
        };
        
        ALAssetsLibraryAccessFailureBlock failureblock  = ^(NSError *myerror)
        {
            NSLog(@"can't get image");
        };
        NSURL *asseturl = [NSURL URLWithString:p.pic_url];
        [assetslibrary assetForURL:asseturl
                       resultBlock:resultblock
                      failureBlock:failureblock];
    }

}

-(void) reloadPropertyData
{
    [self.colPictures reloadData];
    if (propertiesArray == nil && propertiesArray.count==0 && !store.selectedSubZone)
    {
        self.btnSearchTypes.hidden = NO;
        self.btnSaveType.hidden = YES;
    }
    else
    {
        self.btnSearchTypes.hidden = YES;
        //self.btnSaveType.hidden = NO;
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
