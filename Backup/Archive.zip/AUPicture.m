//
//  AUPicture.m
//  LocationReport
//
//  Created by Mark Deraeve on 18/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "AUPicture.h"


@implementation AUPicture

@dynamic pic_id;
@dynamic pic_seq;
@dynamic pic_url;
@dynamic pic_created;
@dynamic pic_created_by;

@end
