//
//  DBStore.h
//  MyProjectOrganizer
//
//  Created by Mark Deraeve on 02/04/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AUProject.h"
#import "AUPicture.h"
/*
#import "Company.h"
#import "Devices.h"
*/
#import "AUProperty.h"
#import "AUPropertyTemplate.h"
#import "AUZone.h"
#import "AUSubZone.h"
#import "AUTranslation.h"


@interface DBStore : NSObject

+ (NSManagedObjectContext *)  GetManagedObjectContext;

+(void) SaveContext;

+(NSNumber *) GetMaxForEntity:(NSString *) entity AndKeyPath:(NSString *) keyPath AndFetchDescription:(NSString *) fetchDescription AndPredicate:(NSString *) predicateString;


#pragma mark Projects

+ (AUProject *) CreateProject:(NSString *) title AndInfo:(NSString *) info AndDate:(NSDate *) projectDate;

+ (NSArray *) GetOpenProjects;

+ (NSFetchedResultsController *) GetProjectDatesByMonthAndYear: (NSString *) search;

+ (NSFetchedResultsController *) GetProjectDatesByMonthAndYearSortedOnTitle: (NSString *) search;

+ (NSArray *) GetAllProjects;

+ (NSArray *) SearchProject:(NSString *) search;

#pragma mark Zones

+ (AUZone *) CreateZone:(NSString *) title AndInfo:(NSString *) info AndProjectID:(NSNumber *) projectID;

+ (NSArray *) GetOpenZonesForProject:(NSNumber *) projectID;

+ (NSArray *) GetAllZones:(NSNumber *) projectID;

#pragma mark SubZones

+ (AUSubZone *) CreateSubZone:(NSString *) title AndInfo:(NSString *) info AndZoneID:(NSNumber *) zoneID;

+ (NSArray *) GetOpenSubZonesForZone:(NSNumber *) zoneID;

+ (NSArray *) GetAllSubZones:(NSNumber *) zoneID;

#pragma Persons



#pragma mark Properties

+ (AUProperty *) CreateProperty:(NSString *) title AndValue:(NSString *) value AndType:(NSString *) property_type AndPropertyID:(NSNumber *) propertyID;

+ (NSArray *) GetAllPropertiesForID:(NSNumber *) property_id;

/*
+ (Property *) CreateProperty:(NSString *) title AndValue:(NSString *) value AndSubZoneID:(NSNumber *) subZoneID;

+ (Property *) GetProperty:(NSString *) title ForSubzoneID:(NSNumber *) subZoneID;

+ (NSArray *) GetAllPropertiesForSubZone:(NSNumber *) subZoneID;
*/
+(void) DeleteProperty:(AUProperty *) property;

#pragma mark  SubzoneTypes
/*
+ (NSArray *) GetAllSubZoneTypes;

+ (Pro *) GetSybZoneTypeByTitle:(NSString *) title;

+ (SubZoneTypes *) GetSybZoneTypeByID:(NSNumber *) sbID;

+(SubZoneTypes *) CreateSubZoneType:(NSString *) title AndPropertiesForTemplate:(NSArray *) properties;

+(void) UpdateSubZoneTypeProperties:(NSNumber *) sbID AndPropertiesForTemplate:(NSArray *) properties;

+ (void) DeleteSubZoneType:(SubZoneTypes *) sb;

#pragma mark PropertyTemplates

+ (NSArray *) GetAllPropertyTemplatesForSubZoneType:(NSNumber *) subZoneTypeID;

+(void) DeletePropertyTemplate:(PropertyTemplate *) prop_template;*/

#pragma mark Pictures

+ (AUPicture *) CreatePicture:(NSString *)title AndURL:(NSString *) url AndComment:(NSString *) comment AndPictureID:(NSNumber *) pictureID;

+ (NSArray *) GetPicturesID:(NSNumber *) pictureID;

+ (void) DeletePicture:(AUPicture *) pic;

#pragma mark Translations`

+ (NSArray *) GetTranslationsForLanguage:(NSString *) language;

+ (AUTranslation *) CheckTranslation: (NSString *) translation AndLanguageID:(NSString *) language;

@end
