//
//  AUPerson.m
//  LocationReport
//
//  Created by Mark Deraeve on 18/09/14.
//  Copyright (c) 2014 AssistU. All rights reserved.
//

#import "AUPerson.h"


@implementation AUPerson

@dynamic pers_id;
@dynamic pers_firstname;
@dynamic pers_lastname;
@dynamic pers_email;
@dynamic pers_created;
@dynamic pers_created_by;

@end
